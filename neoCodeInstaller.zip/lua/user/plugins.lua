-- put your custom lua plugins in this lua table to be loaded last by packer
return {
  "rebelot/kanagawa.nvim",
  "windwp/windline.nvim"
}
